<?php

return [
    'en.hello' => 'hi',
    'ru.hello' => 'привет',
];