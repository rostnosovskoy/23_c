<?php
defined('INDEX') ? exit('attack!!') : null;
