
!!!<?=$data['message']?>!!!

<br>

<?=$data['lang']->translate('hello')?>